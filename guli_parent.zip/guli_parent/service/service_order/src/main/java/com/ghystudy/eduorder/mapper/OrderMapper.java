package com.ghystudy.eduorder.mapper;

import com.ghystudy.eduorder.entity.Order;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 订单 Mapper 接口
 * </p>
 *
 * @author testjava
 * @since 2023-09-06
 */
public interface OrderMapper extends BaseMapper<Order> {

}
