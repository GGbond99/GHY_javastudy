package com.ghystudy.eduservice.controller;

import com.ghystudy.commonutils.R;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/eduservice/user")

public class EduLoginController {

    //login
    @PostMapping("login")
    public R login(){
        return R.ok().data("token","admin");
    }

    //info
    @GetMapping("info")
    public R info(){
        return R.ok().data("roles","[admin]").data("name","admin").data("avatar","https://ts1.cn.mm.bing.net/th/id/R-C.4cd6ed4a2b6a31996cd37f412b33fce0?rik=NnidI4iZA93WqA&riu=http%3a%2f%2fm.keaiming.com%2fuploads%2fallimg%2f2020081710%2f5fyopl4wgnb.jpg&ehk=YLa2HLGSJrFiLOQ3OJzZrWfhU9wltoE4Zmdb%2fLVGGEM%3d&risl=&pid=ImgRaw&r=0&sres=1&sresct=1");
    }
}
