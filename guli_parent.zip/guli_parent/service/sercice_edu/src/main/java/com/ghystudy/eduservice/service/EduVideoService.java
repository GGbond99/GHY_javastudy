package com.ghystudy.eduservice.service;

import com.ghystudy.eduservice.entity.EduVideo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 课程视频 服务类
 * </p>
 *
 * @author testjava
 * @since 2023-08-28
 */
public interface EduVideoService extends IService<EduVideo> {

    //根据课程ID删小节
    void removeVideoByCourseId(String courseId);
}
